﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Minigames {
    /**
     * Controls the UI elements of the minigame.
     */
    public class MinigameDisplay : MonoBehaviour {

        // Use this for initialization
        void Start() {

        }

        // Update is called once per frame
        void Update() {

        }
    }
}
